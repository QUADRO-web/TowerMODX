<?php
/**
 * Setting Lexicon Entries for Tower
 *
 * @package tower
 * @subpackage lexicon
 */
$_lang['setting_socialfeed.site_key'] = 'Site-Key';
$_lang['setting_socialfeed.site_key_desc'] = 'Site-Key';
$_lang['setting_socialfeed.ip_whitelist'] = 'IP Whitelist';
$_lang['setting_socialfeed.ip_whitelist_desc'] = 'Kommaseparierte Liste von IP-dressen die das Skript aufrufen dürfen.';
