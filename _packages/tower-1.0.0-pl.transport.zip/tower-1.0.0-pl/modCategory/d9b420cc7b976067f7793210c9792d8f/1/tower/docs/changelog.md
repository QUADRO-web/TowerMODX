Changelog for Tower

socialFeed 1.0.0
---------------------------------
+ Initial Version